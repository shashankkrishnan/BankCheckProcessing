﻿using System;
using System.IO;
using Leadtools;
using Leadtools.Codecs;
using Leadtools.ImageProcessing;
using Leadtools.ImageProcessing.Core;
using Leadtools.Forms.Common;
using Leadtools.Ocr;
using Leadtools.Forms.Commands;


namespace ChequeProcesing
{
   
    class Program
    {

        public string fname;
        static void Main(string[] args)
        {
            byte[] license = System.IO.File.ReadAllBytes(@"C:\Users\Administrator\Downloads\eval-license-files_3ab398cb-8418-445a-9f1d-9bd4012fde95\eval-license-files.lic");
            RasterSupport.SetLicense(license, "18weXp1TiZbNbVPDQNEzk4CRDcAfLjAIuN383qJptzPpoM7YamOd13OYxnr5CmFEN5yTcu+aPCSCpLVG9uHIl04jGaF8n0vu");
            bool isLocked = RasterSupport.IsLocked(RasterSupportType.Document);
            if (isLocked)
                Console.WriteLine("Document support is locked");
            else
                Console.WriteLine("Document support is unlocked");
            RasterCodecs codecs = new RasterCodecs();

            // Initialize the BankCheckReader class 
            BankCheckReader checkReader = new BankCheckReader();
            ////////////////////////////
            //DirectoryInfo dir = new DirectoryInfo(LEAD_VARS.ImagesDir);
            //foreach (FileInfo file in dir.GetFiles("*"))
            //{
            //    do the thing
            //    Console.WriteLine(file.Name);
            //    flname.fname = file.Name;

            //    string chequePath = Path.Combine(LEAD_VARS.ImagesDir, file.Name);
            //    RasterImage image = codecs.Load(chequePath);

            //    IOcrEngine ocrEngine = OcrEngineManager.CreateEngine(OcrEngineType.LEAD, false);
            //    ocrEngine.Startup(codecs, null, null, LEAD_VARS.OcrLEADRuntimeDir);
            //    Assign Engine to Reader
            //    checkReader.OcrEngine = ocrEngine;

            //    Set MICR code type
            //    checkReader.MicrFontType = BankCheckMicrFontType.E13b;

            //    handle Process Event
            //    checkReader.Process += new EventHandler<ProgressEventArgs>(reader_Processed);

            //    Process Image
            //    checkReader.ProcessImage(image);

            //    ocrEngine.Shutdown();
            //}

            /////////////////////

            // The bank cheque image
            string chequePath = Path.Combine(LEAD_VARS.ImagesDir, "Cheque_9_1.pdf");
            RasterImage image = codecs.Load(chequePath);

            IOcrEngine ocrEngine = OcrEngineManager.CreateEngine(OcrEngineType.LEAD, false);
            ocrEngine.Startup(codecs, null, null, LEAD_VARS.OcrLEADRuntimeDir);
            // Assign Engine to Reader 
            checkReader.OcrEngine = ocrEngine;

            //Set MICR code type 
            checkReader.MicrFontType = BankCheckMicrFontType.E13b;

            // handle Process Event 
            checkReader.Process += new EventHandler<ProgressEventArgs>(reader_Processed);

            // Process Image 
            checkReader.ProcessImage(image);

            ocrEngine.Shutdown();
            //////////////////////////
        }
        static void reader_Processed(object sender, ProgressEventArgs e)
        {
            Console.WriteLine(string.Format("State      : {0}%", e.State));
            Console.WriteLine(string.Format("Percentage : {0}%", e.Percentage));
            Console.WriteLine(string.Format("FieldType  : {0}%", e.FieldType.ToString()));

            if (e.State == ProcessState.Finish)
            {
                BankCheckReader reader = sender as BankCheckReader;
                //////////
                //string outpath = @"C:\Cheque Processing\Cheques\Output\" + flname.fname + ".txt";
                //File.Create(outpath).Dispose();
                ////////

                foreach (var value in reader.Results)
                {
                    
                    LeadRect bounds = value.Value.Bounds;
                    //using (StreamWriter sw = File.AppendText(outpath))
                    //{

                    //    //tw.WriteLine("The very first line!");
                    //    sw.WriteLine(string.Format("Field Name      : {0}", value.Key));
                    //    sw.WriteLine(string.Format("Field Value     : {0}", value.Value.Text));

                    //}

                    Console.WriteLine(string.Format("Field Name      : {0}", value.Key));
                    Console.WriteLine(string.Format("Field Value     : {0}", value.Value.Text));
                    Console.WriteLine(string.Format("Field Bounds    : {0},{0},{0},{0}", bounds.X.ToString(), bounds.Y.ToString(), bounds.Width.ToString(), bounds.Height.ToString()));
                    Console.WriteLine("************************************");
                    
                }
            }
        }

        static class flname
        {
            public static string fname;
        }

        static class LEAD_VARS
        {
            public const string ImagesDir = @"C:\Cheque Processing\Cheques\Cheques";
            public const string OcrLEADRuntimeDir = @"C:\LEADTOOLS 20\Bin\Common\OcrLEADRuntime";
        }


    }
}
